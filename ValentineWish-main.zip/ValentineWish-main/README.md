
* Fork the repository
* Open `customize.json` and replace name/wish-message/image with your own
* Turn on GitHub pages for the repository (Settings > GitHub Pages)
* Send the URL that you get at the above step to your friend

